function psi=psi_function(y,K)

psi=(y(1)+2*y(2))/2+(K(8)-sqrt(K(8)^2+8*K(7)*K(8)*(y(1)+2*y(2))))/(8*K(7));