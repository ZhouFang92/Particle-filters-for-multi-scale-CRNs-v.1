function h=h_function(x)

h=min(x(1)+2*x(2),1000);