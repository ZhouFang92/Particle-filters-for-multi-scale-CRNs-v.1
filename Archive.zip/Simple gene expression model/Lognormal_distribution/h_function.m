function h=h_function(x)

h=10*min(x(4),100);